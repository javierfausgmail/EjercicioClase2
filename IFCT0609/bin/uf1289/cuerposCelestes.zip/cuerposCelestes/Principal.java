package uf1289.cuerposCelestes;

import java.util.ArrayList;
import java.util.Iterator;

import uf1289.geometria.Planeta2;

public class Principal {


	public static void main(String[] args) {
		
		Planeta planeta = new Planeta("Tierra", 4750f, "Azul", 345677f);
		
		Asteroide ast = new Asteroide(123f, "rojo", 100, 300, 43.7f);
		
		planeta.getArea();
		
		planeta.traslacion();
		planeta.rotacion();
		
//		Movimiento mov = new Movimiento();
		EsferaAbstracta esf = planeta;
		System.out.println( "Perimetro planeta/esfera:" + esf.getPerimetro()  );
		
		esf=ast;
		System.out.println( "Perimero del asteroide/esfera:" + esf.getPerimetro());
		 
		 
		 
	}

}
