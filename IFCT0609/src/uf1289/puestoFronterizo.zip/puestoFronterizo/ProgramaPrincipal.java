package uf1289.puestoFronterizo;


public class ProgramaPrincipal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		PuestoFronterizo miPuesto= new PuestoFronterizo();
		
		
		miPuesto.pasoDeFrontera("juan", "56453875H");
		miPuesto.pasoDeFrontera("Mario", "77453875H");
		
		
		miPuesto.buscarNombre("Juan");
		miPuesto.buscarDNI("56453875H");
		
		miPuesto.mostrarTodasPersonas();
		
		//..  hacer men�...
		

		
	}

}
