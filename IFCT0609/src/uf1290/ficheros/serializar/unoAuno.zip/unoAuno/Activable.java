package uf1290.ficheros.serializar.unoAuno;

public interface Activable {
    
    public boolean isActivado();
    
    public void setActivado(boolean value);
    
}
